room reservation
room occupancy
room cancelation

food orders

rooms advance payment

