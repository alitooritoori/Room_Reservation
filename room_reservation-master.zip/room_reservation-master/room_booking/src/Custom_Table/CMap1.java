/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Custom_Table;
import java.awt.Color;
import javax.swing.*;
import javax.swing.table.*;
class CMap1 implements CMap
{
    
  public int span(int row, int column)  {
    if ((row==3) &&(column==3)) return 6;
    if ((row==4)&& (column==7)) return 2;
    if ((row==9)&&(column==5)) return 3;
    return 1;
  }
  public int visibleCell(int row, int column)  {
    if ((row==3)&& (column>=3)&&(column<9)) 
      return 3;
    if ((row==4)&&(column>=7)&&(column <9)) 
    	return 7;
    if ((row==9)&&(column>=5)&&(column<8))
      return 5;
    return column;
  }
}

//    @Override
//    public int visibleCell(Color red, int i) {
//        
//        return 0;
//}